module.exports = {
    // On Hosting provider
    // mongodb://user:pass@ip(or host):port/dbname
    dbStr: 'mongodb://nodejs:123456@localhost:27017/classifields'
}