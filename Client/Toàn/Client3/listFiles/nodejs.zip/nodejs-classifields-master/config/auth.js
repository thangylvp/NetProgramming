module.exports = {
    'facebookAuth': {
        'clientID': '221099185056312',
        'clientSecret': '7e1386ac59e224400282de69bcedd79a',
        'callbackURL': '../thanh-vien/facebook/callback',
        'profileFields': ['birthday', 'emails', 'first_name', 'last_name', 'gender']
    },
    'googleAuth': {
        'clientID': '406353062895-ifeg033ovbdmhaisbrdb7vfh7aagh82k.apps.googleusercontent.com',
        'clientSecret': 'hY1D1Rv0ysYfsvIoo1cW1KgQ',
        'callbackURL': '../thanh-vien/google/callback'
    }
};