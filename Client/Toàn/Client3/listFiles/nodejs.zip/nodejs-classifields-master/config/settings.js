var settings = {
    siteName: 'Classifield Website',
    defaultTemplate: 'default',
    secured_key: '06vUSNEzq1z9U476UrMEx7xIOPGYfu2m',
    passwordLength: 6,
    confirmRegister: 0
}

module.exports = settings;